import { router, publicProcedure } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { z } from "zod";
import * as db from "./db";

// Ürünler için router tanımı - DÜZELTİLDİ
const adminProductsRouter = router({
    list: publicProcedure.query(async () => {
        return await db.getAllProducts();
    }),
    create: publicProcedure
        .input(z.object({
            name: z.string(),
            category: z.string(),
            price: z.number(),
            description: z.string(),
            image: z.string()
        }))
        .mutation(async ({ input }) => {
            return await db.createProduct(input);
        }),
    update: publicProcedure
        .input(z.object({
            id: z.number(),
            name: z.string(),
            category: z.string(),
            price: z.number(),
            description: z.string(),
            image: z.string()
        }))
        .mutation(async ({ input }) => {
            return await db.updateProduct(input.id, input);
        }),
    delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
            return await db.deleteProduct(input.id);
        }),
});

// Kategoriler için router tanımı
const adminCategoriesRouter = router({
    list: publicProcedure.query(async () => {
        return await db.getAllCategories();
    }),
    create: publicProcedure
        .input(z.object({ 
            label: z.string(), 
            value: z.string(),
            image: z.string().optional() 
        }))
        .mutation(async ({ input }) => {
            return await db.createCategory(input);
        }),
    delete: publicProcedure 
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
            return await db.deleteCategory(input.id);
        }),
});

// Siparişler için router tanımı
const adminOrdersRouter = router({
    list: publicProcedure.query(async () => {
        return await db.getAllOrdersForAdmin();
    }),
    updateStatus: publicProcedure
        .input(z.object({ id: z.number(), status: z.string() }))
        .mutation(async ({ input }) => {
            return await db.updateOrderStatus(input.id, input.status);
        }),
    delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
            return await db.deleteOrder(input.id);
        }),
    create: publicProcedure
        .input(z.object({
            totalAmount: z.number(),
            statusNotes: z.string().optional(),
            orderNumber: z.string(),
        }))
        .mutation(async ({ input }) => {
            return await db.createOrder({
                totalAmount: input.totalAmount,
                statusNotes: input.statusNotes ?? "",
                orderNumber: input.orderNumber,
            });
        }),
});

// Kimlik doğrulama için router tanımı
const authRouter = router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
        return { success: true } as const;
    }),
});

// Müşteri Profili Router
const customerRouter = router({
    // Telefon ile profil getir — siparişler + gem bakiyesi
    get: publicProcedure
        .input(z.object({ phone: z.string() }))
        .query(async ({ input }) => {
            return await db.getCustomerProfile(input.phone);
        }),
    // Tüm müşterileri listele (Admin)
    list: publicProcedure.query(async () => {
        return await db.getAllCustomerProfiles();
    }),
    // Şef notunu güncelle (Admin)
    updateChefNote: publicProcedure
        .input(z.object({ phone: z.string(), note: z.string(), emoji: z.string() }))
        .mutation(async ({ input }) => {
            return await db.updateChefNote(input.phone, input.note, input.emoji);
        }),
});

// Ana router birleştirme
export const appRouter = router({
    system: systemRouter,
    auth: authRouter,
    adminOrders: adminOrdersRouter,
    adminProducts: adminProductsRouter,
    adminCategories: adminCategoriesRouter,
    customers: customerRouter,
});

export type AppRouter = typeof appRouter;
