// server/services/payment.service.ts
import { getDb } from "../db";
import { paymentMethods, payments } from "../../drizzle/schema"; // Yolu kontrol et krall
import { eq } from "drizzle-orm";

export const createPayment = async (data: any) => {
    const db = await getDb();
    if (!db) return null;
    const result = await db.insert(payments).values(data);
    return result;
};

export const getPaymentByOrderId = async (orderId: number) => {
    const db = await getDb();
    if (!db) return null;
    const result = await db.select().from(payments).where(eq(payments.orderId, orderId)).limit(1);
    return result[0] ?? null;
};

// �NEML�: Dashboard'un �deme y�ntemlerini g�rmesi i�in buras� bo� d�nmemeli
export const getActivePaymentMethods = async () => {
    const db = await getDb();
    if (!db) return [];
    return await db.select().from(paymentMethods).where(eq(paymentMethods.isActive, 1));
};

export const getAllPaymentMethods = async () => {
    const db = await getDb();
    if (!db) return [];
    return await db.select().from(paymentMethods);
};

export const getPaymentMethodBySlug = async (slug: string) => {
    const db = await getDb();
    if (!db) return null;
    const result = await db.select().from(paymentMethods).where(eq(paymentMethods.slug, slug)).limit(1);
    return result[0] ?? null;
};

// Varsay�lan �deme y�ntemlerini olu�turma (Uygulama ilk a��ld���nda �al���r)
export const initializeDefaultPaymentMethods = async () => {
    const db = await getDb();
    if (!db) return false;

    const existing = await db.select().from(paymentMethods).limit(1);
    if (existing.length > 0) return true;

    const defaults = [
        { name: "Kap�da �deme", slug: "cash", isActive: 1, displayOrder: 1 },
        { name: "Kredi Kart�", slug: "card", isActive: 1, displayOrder: 2 }
    ];

    for (const method of defaults) {
        await db.insert(paymentMethods).values(method);
    }
    return true;
};

// Di�er update/delete fonksiyonlar�n� da benzer �ekilde db �zerinden g�ncelleyebilirsin.