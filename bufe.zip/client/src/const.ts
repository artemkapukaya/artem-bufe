export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const getLoginUrl = () => {
    // .env dosyas�ndan gelen de�erler (Yoksa bo� string d�ner, undefined kalmaz)
    const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL || "";
    const appId = import.meta.env.VITE_APP_ID || "missing-app-id";

    const redirectUri = typeof window !== "undefined"
        ? `${window.location.origin}/api/oauth/callback`
        : "";
    const state = btoa(redirectUri);

    try {
        // E�er oauthPortalUrl bo�sa veya ge�ersizse new URL hata f�rlat�r, onu yakal�yoruz
        const base = oauthPortalUrl.startsWith('http') ? oauthPortalUrl : `https://${oauthPortalUrl}`;
        const url = new URL(`${base}/app-auth`);

        url.searchParams.set("appId", appId);
        url.searchParams.set("redirectUri", redirectUri);
        url.searchParams.set("state", state);
        url.searchParams.set("type", "signIn");

        return url.toString();
    } catch (error) {
        // Hata durumunda uygulama ��kmez, konsola uyar� basar
        console.warn("Login URL olu�turulamad�: VITE_OAUTH_PORTAL_URL eksik veya hatal�.");
        return "/login-error";
    }
};