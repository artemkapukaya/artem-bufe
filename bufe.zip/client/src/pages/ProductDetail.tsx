import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { ChevronLeft, Plus, Minus, ShoppingCart, Check, X as XIcon } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useCart } from "@/contexts/CartContext";
import { products as staticProducts } from "@/lib/data";
import { toast } from "sonner";
import SmartRecommendation from "@/components/SmartRecommendation";

// ── Seçenek Sistemi ───────────────────────────────────────────────────────────
// Admin panelinden veya data.ts'den geliyor — şimdilik kategori bazlı varsayılanlar
interface OptionGroup {
  id: string;
  name: string;
  type: "single" | "multi" | "remove";  // tek seçim, çoklu, çıkar
  required: boolean;
  items: OptionItem[];
}

interface OptionItem {
  id: string;
  label: string;
  priceModifier: number;  // kuruş cinsinden, negatif = indirim, 0 = bedava
  isDefault?: boolean;    // varsayılan seçili
}

// Kategori bazlı seçenek şablonları
const OPTION_TEMPLATES: Record<string, OptionGroup[]> = {
  // Çiğ ürünler / Çiğ köfte
  "cig-urunler": [
    {
      id: "size", name: "Porsiyon", type: "single", required: true,
      items: [
        { id: "s1", label: "Küçük", priceModifier: 0, isDefault: true },
        { id: "s2", label: "Orta", priceModifier: 1500 },
        { id: "s3", label: "Büyük", priceModifier: 3000 },
      ]
    },
    {
      id: "remove", name: "Çıkarılacak Malzeme", type: "remove", required: false,
      items: [
        { id: "r1", label: "Acı Biber Sosu", priceModifier: 0 },
        { id: "r2", label: "Nar Ekşisi", priceModifier: 0 },
        { id: "r3", label: "Turşu", priceModifier: 0 },
        { id: "r4", label: "Soğan", priceModifier: 0 },
        { id: "r5", label: "Maydanoz", priceModifier: 0 },
        { id: "r6", label: "Limon", priceModifier: 0 },
      ]
    },
    {
      id: "add", name: "Ekstra İstekler", type: "multi", required: false,
      items: [
        { id: "a1", label: "Ekstra Acı", priceModifier: 0 },
        { id: "a2", label: "Ekstra Nar Ekşisi", priceModifier: 0 },
        { id: "a3", label: "Yanında Lavaş", priceModifier: 500 },
        { id: "a4", label: "Ekstra Roka", priceModifier: 0 },
      ]
    },
    {
      id: "lavash", name: "Lavaş Seçimi", type: "single", required: false,
      items: [
        { id: "l1", label: "Lavaşsız", priceModifier: 0, isDefault: true },
        { id: "l2", label: "İnce Lavaş", priceModifier: 500 },
        { id: "l3", label: "Kalın Lavaş", priceModifier: 500 },
        { id: "l4", label: "Tam Buğday Lavaş", priceModifier: 500 },
      ]
    },
  ],
  // Izgara ürünler
  "izgara-urunler": [
    {
      id: "cooking", name: "Pişirme Derecesi", type: "single", required: true,
      items: [
        { id: "c1", label: "Az Pişmiş", priceModifier: 0 },
        { id: "c2", label: "Orta Pişmiş", priceModifier: 0, isDefault: true },
        { id: "c3", label: "Tam Pişmiş", priceModifier: 0 },
        { id: "c4", label: "Çok Pişmiş", priceModifier: 0 },
      ]
    },
    {
      id: "sauce", name: "Sos Seçimi", type: "single", required: false,
      items: [
        { id: "s1", label: "Sosgz", priceModifier: 0, isDefault: true },
        { id: "s2", label: "Acı Sos", priceModifier: 0 },
        { id: "s3", label: "Sarımsaklı Sos", priceModifier: 0 },
        { id: "s4", label: "BBQ Sos", priceModifier: 0 },
      ]
    },
    {
      id: "remove", name: "Çıkarılacak", type: "remove", required: false,
      items: [
        { id: "r1", label: "Soğan", priceModifier: 0 },
        { id: "r2", label: "Domates", priceModifier: 0 },
        { id: "r3", label: "Biber", priceModifier: 0 },
      ]
    },
    {
      id: "extras", name: "Ekstralar", type: "multi", required: false,
      items: [
        { id: "e1", label: "Ekstra Peynir", priceModifier: 1500 },
        { id: "e2", label: "Ekstra Et", priceModifier: 3000 },
        { id: "e3", label: "Yanında Patates", priceModifier: 3000 },
      ]
    },
  ],
  // Ekmek arası / Burger
  "ekmek-arasi": [
    {
      id: "bread", name: "Ekmek Seçimi", type: "single", required: false,
      items: [
        { id: "b1", label: "Normal Ekmek", priceModifier: 0, isDefault: true },
        { id: "b2", label: "Tam Buğday", priceModifier: 0 },
        { id: "b3", label: "Susam Ekmek", priceModifier: 0 },
        { id: "b4", label: "Dürüm", priceModifier: 0 },
      ]
    },
    {
      id: "remove", name: "Çıkarılacak Malzeme", type: "remove", required: false,
      items: [
        { id: "r1", label: "Soğan", priceModifier: 0 },
        { id: "r2", label: "Domates", priceModifier: 0 },
        { id: "r3", label: "Turşu", priceModifier: 0 },
        { id: "r4", label: "Marul", priceModifier: 0 },
        { id: "r5", label: "Sos", priceModifier: 0 },
      ]
    },
    {
      id: "sauce", name: "Sos Ekle", type: "multi", required: false,
      items: [
        { id: "s1", label: "Ketçap", priceModifier: 0 },
        { id: "s2", label: "Mayonez", priceModifier: 0 },
        { id: "s3", label: "Hardal", priceModifier: 0 },
        { id: "s4", label: "Acı Sos", priceModifier: 0 },
        { id: "s5", label: "Sarımsaklı Sos", priceModifier: 0 },
      ]
    },
    {
      id: "extras", name: "Ekstralar", type: "multi", required: false,
      items: [
        { id: "e1", label: "Çift Kat Et", priceModifier: 2000 },
        { id: "e2", label: "Ekstra Peynir", priceModifier: 1000 },
        { id: "e3", label: "Yumurta Ekle", priceModifier: 1000 },
        { id: "e4", label: "Bacon Ekle", priceModifier: 2000 },
      ]
    },
  ],
  // Döner
  "doner": [
    {
      id: "type", name: "Servis Şekli", type: "single", required: true,
      items: [
        { id: "t1", label: "Tabak", priceModifier: 0, isDefault: true },
        { id: "t2", label: "Dürüm", priceModifier: 0 },
        { id: "t3", label: "Ekmek Arası", priceModifier: 0 },
      ]
    },
    {
      id: "remove", name: "Çıkarılacak", type: "remove", required: false,
      items: [
        { id: "r1", label: "Soğan", priceModifier: 0 },
        { id: "r2", label: "Domates", priceModifier: 0 },
        { id: "r3", label: "Maydanoz", priceModifier: 0 },
        { id: "r4", label: "Turşu", priceModifier: 0 },
      ]
    },
    {
      id: "sauce", name: "Sos", type: "single", required: false,
      items: [
        { id: "s1", label: "Acı Sos", priceModifier: 0 },
        { id: "s2", label: "Sarımsaklı Sos", priceModifier: 0 },
        { id: "s3", label: "Sosgz", priceModifier: 0, isDefault: true },
      ]
    },
  ],
  // Çıtır / Soğuk ürünler
  "citir-soguk": [
    {
      id: "sauce", name: "Sos Seçimi", type: "single", required: false,
      items: [
        { id: "s1", label: "Ketçap", priceModifier: 0 },
        { id: "s2", label: "Mayonez", priceModifier: 0 },
        { id: "s3", label: "Acı Sos", priceModifier: 0 },
        { id: "s4", label: "Ranch Sos", priceModifier: 0 },
        { id: "s5", label: "Sosgz", priceModifier: 0, isDefault: true },
      ]
    },
  ],
  // Tatlı
  "tatli-icecek": [
    {
      id: "extras", name: "Ekstra", type: "multi", required: false,
      items: [
        { id: "e1", label: "Fıstık Ekle", priceModifier: 1000 },
        { id: "e2", label: "Dondurma Ekle", priceModifier: 2000 },
        { id: "e3", label: "Ekstra Kaymak", priceModifier: 1500 },
      ]
    },
  ],
  // Çorba/Kahvaltı
  "corba-kahvalti": [
    {
      id: "size", name: "Boy", type: "single", required: true,
      items: [
        { id: "s1", label: "Küçük", priceModifier: 0, isDefault: true },
        { id: "s2", label: "Büyük (Porsiyon)", priceModifier: 2000 },
      ]
    },
    {
      id: "extras", name: "Ekstra", type: "multi", required: false,
      items: [
        { id: "e1", label: "Ekstra Ekmek", priceModifier: 500 },
        { id: "e2", label: "Tereyağı", priceModifier: 500 },
      ]
    },
  ],
};

// Varsayılan seçenekler (eşleşme yoksa)
const DEFAULT_OPTIONS: OptionGroup[] = [
  {
    id: "note", name: "Özel İstek", type: "multi", required: false,
    items: [
      { id: "n1", label: "Az Tuzlu", priceModifier: 0 },
      { id: "n2", label: "Az Yağlı", priceModifier: 0 },
      { id: "n3", label: "Acısız", priceModifier: 0 },
    ]
  }
];

interface SelectedCustom {
  groupId: string;
  groupName: string;
  groupType: "single" | "multi" | "remove";
  itemId: string;
  label: string;
  priceModifier: number;
}

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const [, navigate] = useLocation();
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedCustom, setSelectedCustom] = useState<SelectedCustom[]>([]);
  const [showRecommendation, setShowRecommendation] = useState(false);

  // Custom ürünleri dinamik yükle
  const [allProducts, setAllProducts] = useState(() => {
    try {
      const custom = JSON.parse(localStorage.getItem("artem_custom_products") || "[]");
      return [...staticProducts, ...custom];
    } catch { return [...staticProducts]; }
  });

  useEffect(() => {
    const load = () => {
      try {
        const custom = JSON.parse(localStorage.getItem("artem_custom_products") || "[]");
        setAllProducts([...staticProducts, ...custom]);
      } catch {}
    };
    window.addEventListener("artem_products_updated", load);
    return () => window.removeEventListener("artem_products_updated", load);
  }, []);

  const productId = params?.id;
  const product = productId ? allProducts.find((p) => p.id === productId) : null;

  // Ürünün kategorisine göre seçenek grupları
  const optionGroups: OptionGroup[] = product
    ? (OPTION_TEMPLATES[product.category] ?? DEFAULT_OPTIONS)
    : [];

  // Varsayılan seçimleri başlat
  useEffect(() => {
    if (!product) return;
    const defaults: SelectedCustom[] = [];
    optionGroups.forEach(group => {
      group.items.filter(i => i.isDefault).forEach(item => {
        defaults.push({
          groupId: group.id, groupName: group.name, groupType: group.type,
          itemId: item.id, label: item.label, priceModifier: item.priceModifier,
        });
      });
    });
    setSelectedCustom(defaults);
  }, [product?.id]);

  const handleSelect = (group: OptionGroup, item: OptionItem) => {
    setSelectedCustom(prev => {
      if (group.type === "single") {
        // Aynı gruptan diğerlerini kaldır
        const filtered = prev.filter(s => s.groupId !== group.id);
        // Zaten seçiliyse kaldır (toggle — zorunlu değilse)
        const alreadySelected = prev.find(s => s.groupId === group.id && s.itemId === item.id);
        if (alreadySelected && !group.required) return filtered;
        return [...filtered, { groupId: group.id, groupName: group.name, groupType: group.type, itemId: item.id, label: item.label, priceModifier: item.priceModifier }];
      } else {
        // Multi / remove — toggle
        const exists = prev.find(s => s.groupId === group.id && s.itemId === item.id);
        if (exists) return prev.filter(s => !(s.groupId === group.id && s.itemId === item.id));
        return [...prev, { groupId: group.id, groupName: group.name, groupType: group.type, itemId: item.id, label: item.label, priceModifier: item.priceModifier }];
      }
    });
  };

  const isSelected = (groupId: string, itemId: string) =>
    selectedCustom.some(s => s.groupId === groupId && s.itemId === itemId);

  // Toplam fiyat
  const extraPrice = selectedCustom.reduce((sum, s) => sum + s.priceModifier, 0) / 100;
  const totalUnitPrice = (product?.price ?? 0) + extraPrice;

  const handleAddToCart = () => {
    if (!product) return;

    // Zorunlu grupları kontrol et
    const missingRequired = optionGroups
      .filter(g => g.required && !selectedCustom.find(s => s.groupId === g.id))
      .map(g => g.name);

    if (missingRequired.length > 0) {
      toast.error(`Lütfen seçin: ${missingRequired.join(", ")}`);
      return;
    }

    // Seçim özeti
    const removes = selectedCustom.filter(s => s.groupType === "remove").map(s => s.label);
    const adds = selectedCustom.filter(s => s.groupType !== "remove" && s.priceModifier === 0 && !s.label.includes("sız") && !s.label.includes("gez")).map(s => s.label);
    const extras = selectedCustom.filter(s => s.priceModifier > 0).map(s => s.label);

    let productName = product.name;
    if (removes.length > 0) productName += ` (${removes.map(r => r + " yok").join(", ")})`;

    for (let i = 0; i < quantity; i++) {
      addItem({
        id: `${product.id}-${Date.now()}-${i}`,
        name: productName,
        price: totalUnitPrice,
        image: product.image,
        selectedOptions: selectedCustom.map(s => ({
          name: s.groupName,
          value: s.label,
          priceModifier: s.priceModifier,
        })),
      });
    }

    toast.success(`${quantity}x ${product.name} sepete eklendi!`);
    setQuantity(1);

    // Satış sayacı
    const salesKey = `artem_sales_${product.id}`;
    const cur = Number(localStorage.getItem(salesKey) ?? Math.floor(10 + Math.random() * 90));
    localStorage.setItem(salesKey, String(cur + quantity));
    setTimeout(() => setShowRecommendation(true), 600);
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="h-14 md:h-16" />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <p className="text-gray-600">Ürün bulunamadı</p>
          <button onClick={() => navigate("/menu")} className="mt-4 px-6 py-2 bg-orange-500 text-white font-bold rounded-lg hover:bg-orange-600">
            Menüye Dön
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  const salesKey = `artem_sales_${product.id}`;
  const sales = Number(localStorage.getItem(salesKey) ?? Math.floor(10 + Math.random() * 90));
  const likes = Math.floor(sales * 0.8);
  const todayCount = Math.floor(sales * 0.15) + 1;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="h-14 md:h-16" />

      <div className="max-w-6xl mx-auto px-4 py-6">
        <button onClick={() => navigate(-1 as any)} className="flex items-center gap-2 text-orange-600 font-bold mb-6 hover:text-orange-700">
          <ChevronLeft size={20} /> Geri Dön
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Sol — Görsel */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <img src={product.image || "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=600&h=450&fit=crop"}
                alt={product.name} className="w-full h-80 object-cover"
                onError={e => { e.currentTarget.src = "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=600&h=450&fit=crop"; }} />
            </div>

            {/* Sosyal kanıt */}
            <div className="flex flex-wrap gap-2">
              <span className="bg-red-50 border border-red-100 text-red-600 text-xs font-bold px-3 py-1.5 rounded-full">❤️ {likes} kişi beğendi</span>
              <span className="bg-orange-50 border border-orange-100 text-orange-600 text-xs font-bold px-3 py-1.5 rounded-full">🔥 Bugün {todayCount} kez sipariş edildi</span>
              {sales > 50 && <span className="bg-green-50 border border-green-100 text-green-600 text-xs font-bold px-3 py-1.5 rounded-full">⭐ Çok Satan</span>}
            </div>

            {/* Bilgi kartı */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-1.5">
              <p className="text-sm text-blue-900"><span className="font-bold">📦 Hızlı Teslimat:</span> 30-45 dakika</p>
              <p className="text-sm text-blue-900"><span className="font-bold">✅ Taze Malzeme:</span> Her gün taze hazırlanır</p>
              <p className="text-sm text-blue-900"><span className="font-bold">⭐ Sadakat Puanı:</span> Bu siparişten Gem kazanın</p>
            </div>
          </div>

          {/* Sağ — Detaylar + Seçenekler */}
          <div className="space-y-5">
            {/* Başlık + Fiyat */}
            <div>
              <h1 className="text-3xl font-black text-gray-800 mb-2">{product.name}</h1>
              <p className="text-gray-500 mb-3">{product.description}</p>
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-black text-red-600">
                  {totalUnitPrice.toLocaleString("tr-TR")} TL
                </span>
                {extraPrice > 0 && (
                  <span className="text-sm text-gray-400">
                    ({product.price.toLocaleString("tr-TR")} + {extraPrice.toLocaleString("tr-TR")} TL ekstra)
                  </span>
                )}
              </div>
            </div>

            {/* Seçenek Grupları */}
            {optionGroups.map(group => (
              <div key={group.id} className={`rounded-2xl border p-4 space-y-3 ${
                group.type === "remove"
                  ? "bg-red-50 border-red-100"
                  : group.type === "single"
                  ? "bg-white border-gray-200"
                  : "bg-green-50 border-green-100"
              }`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-black text-gray-800 flex items-center gap-2">
                    {group.type === "remove" ? "🚫" : group.type === "single" ? "✓" : "➕"}
                    {group.name}
                    {group.required && <span className="text-red-500 text-xs font-bold">*zorunlu</span>}
                  </h3>
                  <span className="text-xs text-gray-400 font-bold">
                    {group.type === "single" ? "Tek seçim" : group.type === "remove" ? "Çıkart" : "Çoklu seçim"}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {group.items.map(item => {
                    const selected = isSelected(group.id, item.id);
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleSelect(group, item)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-bold border-2 transition-all ${
                          selected
                            ? group.type === "remove"
                              ? "bg-red-500 text-white border-red-500"
                              : "bg-orange-500 text-white border-orange-500 shadow-md"
                            : "bg-white text-gray-700 border-gray-200 hover:border-orange-300"
                        }`}
                      >
                        {selected ? (
                          group.type === "remove" ? <XIcon size={13} /> : <Check size={13} />
                        ) : null}
                        {item.label}
                        {item.priceModifier > 0 && (
                          <span className={`text-xs ${selected ? "opacity-80" : "text-orange-500"}`}>
                            +{(item.priceModifier / 100).toFixed(0)} TL
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Seçim özeti */}
            {selectedCustom.length > 0 && (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-3">
                <p className="text-xs font-black text-gray-400 uppercase tracking-wide mb-2">Seçimleriniz</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedCustom.map((s, i) => (
                    <span key={i} className={`text-xs font-bold px-2 py-1 rounded-lg ${
                      s.groupType === "remove"
                        ? "bg-red-100 text-red-600 line-through"
                        : "bg-orange-100 text-orange-700"
                    }`}>
                      {s.groupType === "remove" ? `🚫 ${s.label}` : s.label}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Adet */}
            <div className="flex items-center gap-4">
              <label className="font-bold text-sm text-gray-700">Adet:</label>
              <div className="flex items-center gap-3 bg-white rounded-xl border border-gray-200 p-2">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="text-gray-600 hover:text-orange-600 transition-colors p-1">
                  <Minus size={18} />
                </button>
                <span className="font-black text-lg text-gray-800 w-8 text-center">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="text-gray-600 hover:text-orange-600 transition-colors p-1">
                  <Plus size={18} />
                </button>
              </div>
              <span className="text-gray-400 text-sm font-bold">
                Toplam: <span className="text-orange-600 font-black">{(totalUnitPrice * quantity).toLocaleString("tr-TR")} TL</span>
              </span>
            </div>

            {/* Sepete Ekle */}
            <button onClick={handleAddToCart}
              className="w-full py-4 bg-gradient-to-r from-red-600 to-orange-500 text-white font-black text-lg rounded-xl
                         hover:from-red-500 hover:to-orange-400 transition-all duration-200 shadow-lg
                         flex items-center justify-center gap-2 active:scale-95">
              <ShoppingCart size={20} />
              Sepete Ekle — {(totalUnitPrice * quantity).toLocaleString("tr-TR")} TL
            </button>
          </div>
        </div>
      </div>

      {showRecommendation && product && (
        <SmartRecommendation
          addedProductId={product.id}
          addedProductCategory={product.category}
          onClose={() => setShowRecommendation(false)}
        />
      )}
      <Footer />
    </div>
  );
}
