import { useState } from "react";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface PaymentMethod {
  id: number;
  name: string;
  slug: string;
  icon?: string;
  color?: string;
  description?: string;
  isActive: number;
  displayOrder: number;
  commissionRate: string;
  minAmount: number;
  maxAmount: number;
}

export default function AdminPaymentMethods() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: 1,
      name: "Kapıda Ödeme",
      slug: "cash",
      icon: "🚚",
      color: "#10B981",
      description: "Teslimat sırasında nakit ödeme",
      isActive: 1,
      displayOrder: 1,
      commissionRate: "0.00",
      minAmount: 0,
      maxAmount: 999999999,
    },
    {
      id: 2,
      name: "Kredi Kartı",
      slug: "card",
      icon: "💳",
      color: "#3B82F6",
      description: "Güvenli kredi kartı ödemesi",
      isActive: 1,
      displayOrder: 2,
      commissionRate: "2.00",
      minAmount: 0,
      maxAmount: 999999999,
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<Partial<PaymentMethod>>({
    name: "",
    slug: "",
    icon: "",
    color: "#000000",
    description: "",
    isActive: 1,
    displayOrder: 0,
    commissionRate: "0.00",
    minAmount: 0,
    maxAmount: 999999999,
  });

  const handleAdd = () => {
    setEditingId(null);
    setFormData({
      name: "",
      slug: "",
      icon: "",
      color: "#000000",
      description: "",
      isActive: 1,
      displayOrder: 0,
      commissionRate: "0.00",
      minAmount: 0,
      maxAmount: 999999999,
    });
    setShowForm(true);
  };

  const handleEdit = (method: PaymentMethod) => {
    setEditingId(method.id);
    setFormData(method);
    setShowForm(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.slug) {
      toast.error("Lütfen tüm gerekli alanları doldurunuz");
      return;
    }

    if (editingId) {
      setPaymentMethods(
        paymentMethods.map((m) =>
          m.id === editingId ? { ...m, ...formData } : m
        )
      );
      toast.success("Ödeme yöntemi güncellendi");
    } else {
      const newMethod: PaymentMethod = {
        id: Math.max(...paymentMethods.map((m) => m.id), 0) + 1,
        name: formData.name || "",
        slug: formData.slug || "",
        icon: formData.icon,
        color: formData.color,
        description: formData.description,
        isActive: formData.isActive || 1,
        displayOrder: formData.displayOrder || 0,
        commissionRate: formData.commissionRate || "0.00",
        minAmount: formData.minAmount || 0,
        maxAmount: formData.maxAmount || 999999999,
      };
      setPaymentMethods([...paymentMethods, newMethod]);
      toast.success("Ödeme yöntemi eklendi");
    }

    setShowForm(false);
    setEditingId(null);
  };

  const handleDelete = (id: number) => {
    if (confirm("Bu ödeme yöntemini silmek istediğinize emin misiniz?")) {
      setPaymentMethods(paymentMethods.filter((m) => m.id !== id));
      toast.success("Ödeme yöntemi silindi");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold">Ödeme Yöntemleri</h3>
        <Button onClick={handleAdd} size="sm" className="gap-2">
          <Plus size={16} />
          Yeni Yöntem
        </Button>
      </div>

      {showForm && (
        <div className="border rounded-lg p-4 bg-gray-50">
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="Adı"
              value={formData.name || ""}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
            />
            <Input
              placeholder="Slug"
              value={formData.slug || ""}
              onChange={(e) =>
                setFormData({ ...formData, slug: e.target.value })
              }
            />
            <Input
              placeholder="İkon"
              value={formData.icon || ""}
              onChange={(e) =>
                setFormData({ ...formData, icon: e.target.value })
              }
            />
            <Input
              type="color"
              value={formData.color || "#000000"}
              onChange={(e) =>
                setFormData({ ...formData, color: e.target.value })
              }
            />
            <Input
              placeholder="Açıklama"
              value={formData.description || ""}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              className="col-span-2"
            />
            <Input
              type="number"
              placeholder="Komisyon Oranı (%)"
              value={formData.commissionRate || "0.00"}
              onChange={(e) =>
                setFormData({ ...formData, commissionRate: e.target.value })
              }
            />
            <Input
              type="number"
              placeholder="Sıra"
              value={formData.displayOrder || 0}
              onChange={(e) =>
                setFormData({ ...formData, displayOrder: parseInt(e.target.value) })
              }
            />
          </div>
          <div className="flex gap-2 mt-4">
            <Button onClick={handleSave} size="sm">
              Kaydet
            </Button>
            <Button
              onClick={() => setShowForm(false)}
              size="sm"
              variant="outline"
            >
              İptal
            </Button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 text-left">Adı</th>
              <th className="px-4 py-2 text-left">Slug</th>
              <th className="px-4 py-2 text-left">Komisyon</th>
              <th className="px-4 py-2 text-left">Durum</th>
              <th className="px-4 py-2 text-left">İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {paymentMethods.map((method) => (
              <tr key={method.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-2">{method.name}</td>
                <td className="px-4 py-2">{method.slug}</td>
                <td className="px-4 py-2">{method.commissionRate}%</td>
                <td className="px-4 py-2">
                  <span
                    className={`px-2 py-1 rounded text-xs font-bold ${
                      method.isActive
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {method.isActive ? "Aktif" : "İnaktif"}
                  </span>
                </td>
                <td className="px-4 py-2 flex gap-2">
                  <button
                    onClick={() => handleEdit(method)}
                    className="p-1 hover:bg-blue-100 rounded"
                  >
                    <Edit2 size={16} className="text-blue-600" />
                  </button>
                  <button
                    onClick={() => handleDelete(method.id)}
                    className="p-1 hover:bg-red-100 rounded"
                  >
                    <Trash2 size={16} className="text-red-600" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
